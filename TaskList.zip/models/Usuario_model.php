<?php
    class Usuario_model {
        private $pdo;
        function __construct(){
            include_once "../settings/db.php";
            $this->db = $pdo; 
        }
        function check_login($usuario, $senha){
            $sql = "SELECT * FROM usuarios WHERE user = :usuario AND `password` = :senha AND delete_flag = 0";
            
            $query = $this->db->prepare($sql);
            $query->bindParam(":usuario",$usuario);
            $query->bindParam(":senha",$senha);
            $query->execute();
            $resultados = $query->fetchAll(PDO::FETCH_ASSOC);

            return $resultados;
        }
    }

    
    // Criando a instância
    //$usuario = new Usuario_model($pdo);