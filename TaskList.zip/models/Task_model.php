<?php
    include_once "/settings/db.php";
    class Task {
        function __construct(){
            $this->db = $pdo;  
        }
    }
?>