<?php
    //includes
    include_once "../settings/helpers.php";
    include_once "../models/usuario_model.php";

    //headers
    //header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type");

    class Usuario {
        function __construct(){
            $this->helpers = new Helpers ; 
            $this->usuario_model = new Usuario_model ; 
            // Detecta método HTTP
            $this->requestMethod = $_SERVER['REQUEST_METHOD'];

            // Captura dados conforme método
            if ($this->requestMethod === "GET") {

                $this->requestData = $_GET; // parâmetros via URL

            } elseif ($this->requestMethod === "POST") {

                $json = file_get_contents("php://input");
                $this->requestData = json_decode($json, true); // parâmetros via body JSON

            } else {
                $this->helpers->responseApi("error", "Método não permitido");
            }

            // Pega ação
            $action = $this->requestData['action'] ?? null;

            if ($action && method_exists($this, $action)) {
                $this->$action(); // chama automaticamente
            } else {
                $this->helpers->responseApi("error", "Ação inválida ou não especificada");
            }
        }

        public function login(){
            try{
                $filters = $this->requestData;
                if(empty($filters['username'])){
                    throw new Exception("Usuario nâo informado");
                }
                
                if(empty($filters['password'])){
                    throw new Exception("Senha nâo informado");
                }
                $usuario = $filters['username'];
                $senha = hash('sha256',$filters['password']);

                $response = $this->usuario_model->check_login($usuario, $senha);
                if(count($response) <= 0){
                    throw new Exception("Usuario não encontrado");
                }
                $this->helpers->responseApi("success","Usuario encontrado com sucesso");
            }
            catch(Exception $e){
                $this->helpers->responseApi("error",$e->getMessage());
            }
        }

        //funao de pegar os usuarios
        public function getUsuario(){
            try{
                $data = [];
            }
            catch(Exception $e){
                $this->helpers->responseApi("error", $e->getMessage());
            }
        }
    }


    // Criando a instância
    $usuario = new Usuario();

